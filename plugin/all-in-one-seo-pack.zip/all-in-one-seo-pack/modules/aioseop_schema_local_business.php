<?php
/**
 * Loads the Local Business schema class.
 * 
 * @since 3.6.0
 */

if ( AIOSEOPPRO ) {
	require_once( AIOSEOP_PLUGIN_DIR . 'pro/modules/class-aioseop-schema-local-business.php' );
}
